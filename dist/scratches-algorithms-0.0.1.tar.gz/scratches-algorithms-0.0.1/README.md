###### scratches

<details><summary> 
<strong>English</strong>
</summary>

# Classical algorithms and simple utilities

</details>

<details><summary> 
<strong>Русский</strong>
</summary>

# Классические алгоритмы и простые утилиты

</details>